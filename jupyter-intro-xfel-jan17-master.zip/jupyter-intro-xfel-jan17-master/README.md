# Introduction to Jupyter Notebook

This is material for a workshop at XFEL in January 2017.

See [Index.ipynb](Index.ipynb) for a table of contents.